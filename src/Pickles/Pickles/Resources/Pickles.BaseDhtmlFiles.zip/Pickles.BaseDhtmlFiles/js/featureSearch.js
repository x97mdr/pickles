﻿function getFeaturesMatching(searchString, features) {
    searchString = searchString.toLowerCase();
    var filteredFeatures = ko.utils.arrayFilter(features, function (feature) {
        if (matchesFeatureName(searchString, feature) ||
            matchesFeatureTag(searchString, feature) ||
            matchesFeatureDescription(searchString, feature) || 

            matchesScenarioName(searchString, feature) ||
            matchesScenarioTag(searchString, feature) ||
            matchesScenarioDescription(searchString, feature) || 
            matchesStepText(searchString, feature) || 
            
            matchesAnythingInBackground(searchString, feature)  || 
            matchesScenarioOutline(searchString, feature)) {
            return feature;
        } else {
            return null;
        }
    });

    return filteredFeatures;
}

function matchString(actual, searchString){
    return actual
            .toLowerCase()
            .indexOf(searchString) > -1;
};

function findFeatureByRelativeFolder(path, features) {
    var feature = _.find(features, function(featureTesting) {
         return featureTesting.RelativeFolder == path;
    });
    return feature ? feature : null;
}

// Feature search
function matchesFeatureDescription(searchString, feature){
   return matchString(feature.Feature.Description, searchString);
}

function matchesFeatureName(searchString, feature) {
    return matchString(feature.Feature.Name, searchString);
}

function matchesFeatureTag(searchString, feature) {
    var featureTags = feature.Feature.Tags;
    return (_.indexOf(featureTags, searchString) > -1);
}

// Scenario search
function matchesScenarioName(searchString, feature) {
    return _.any(feature.Feature.FeatureElements, function(item){
        return matchString(item.Name, searchString);
    });
}

function matchesScenarioTag(searchString, feature) {
    return _.any(feature.Feature.FeatureElements, function(item){
        return _.any(item.Tags, function(tag){
            return matchString(tag, searchString);
        });
    });
}

function matchesScenarioDescription(searchString, feature){
    return _.any(feature.Feature.FeatureElements, function(item){
        return _.any(item.Description, function(description){
            return matchString(description, searchString);
        });
    });
}

// Background search
function matchesAnythingInBackground(searchString, feature){
    if(feature.Feature.Background){
        var background = feature.Feature.Background;

        return matchesBackgroundName(searchString, background) ||
                matchesBackgroundDescription(searchString, background) ||
                matchesBackgroundSteps(searchString, background);
    }
    return false;    
}

function matchesBackgroundDescription(searchString, background){
   return matchString(background.Description, searchString);
}

function matchesBackgroundName(searchString, background) {
    return matchString(background.Name, searchString);
}

function matchesBackgroundSteps(searchString, background){
    _.any(background.Steps, function(step){
            matchString(step.Name, searchString);             
    });
}

// Step search
function getStepsForFeature(feature)
{
    for (var i = 0; i < feature.Feature.FeatureElements.length; i++) {
        return feature.Feature.FeatureElements[i].Steps;
    }

    return [];   
}

function matchesStepText(searchString, feature){
    var steps = getStepsForFeature(feature);

    for(var i = 0; i < steps.length; i++){
    
        if (matchString(steps[i].Name, searchString)) {
            return true;
        }

        if(matchesTable(searchString, steps[i])){
            return true;
        }
    }
    return false;
}

function matchesTable(searchString, step){
    if(step.TableArgument){

        if(matchesTableHeader(searchString, step.TableArgument)){
            return true;
        }  

        if(matchesTableDataRows(searchString, step.TableArgument)){
            return true;
        }         
    }
    return false;
}

function matchesTableHeader(searchString, table){
    return _.any(table.HeaderRow, function(item){
        return matchString(item, searchString); 
    });
}

function matchesTableDataRows(searchString, table){
    return _.any(table.DataRows, function(row){
        return _.any(row, function (item){
            return matchString(item, searchString);
        });              
    });
}

// Scenario outline
function matchesScenarioOutline(searchString, feature){
    for (var i = 0; i < feature.Feature.FeatureElements.length; i++) {
        if(feature.Feature.FeatureElements[i].Examples){

            var examples = feature.Feature.FeatureElements[i].Examples;

            if (matchScenarioOutlineName(searchString, examples) ||
                matchScenarioOutlineDescription(searchString, examples) ||
                matchesScenarioOutlineTableHeader(searchString, examples) ||
                matchesScenarioOutlineDataRow(searchString, examples)) {
                
                return true;
            }
        }
    };
    
    return false;
}

function matchScenarioOutlineName(searchString, examples){
    return _.any(examples, function(example){
        return matchString(example.Name, searchString);            
    });
}

function matchScenarioOutlineDescription(searchString, examples){
    return _.any(examples, function(example){
        return matchString(example.Description, searchString);            
    });
}

function matchesScenarioOutlineTableHeader(searchString, examples){
    return _.any(examples, function(example){
        return matchesTableHeader(searchString, example.TableArgument.HeaderRow);
    });
}

function matchesScenarioOutlineDataRow(searchString, examples){
    return _.any(examples, function(example){
        return matchesTableDataRows(searchString, example.TableArgument.DataRows);
    });
}

